%% ѵ����/���Լ�����
function [posfitG,posmse]=GPglobal(pastpos,pastposfit,D,p)
trainnum=5*D;%%%�����趨��������%same as wanghanding
  [TrainL,TrainD]=size(pastpos); 
IP_train = pastpos;
OT_train = pastposfit;
INput=[ OT_train IP_train];

 if TrainL<=trainnum
     [INput,~,~] = unique(INput,'rows');
     PREIN=INput;
      [PRETrainL,PRETrainD]=size(PREIN); 
 else
      [INput,~,~] = unique(INput,'rows');
      PREIN=INput;
      [PRETrainL,PRETrainD]=size(PREIN); 
      if PRETrainL>trainnum
                   
       PREIN=INput(((PRETrainL-trainnum):PRETrainL),:);%%�Է����ظ��ģ�����������Ϊ����
      [PREIN,~,~] = unique(PREIN,'rows');
      [PRETrainL,PRETrainD]=size(PREIN);
      end
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_train =PREIN(:,(2:D+1));
T_train =PREIN(:,1);
T_test = p;


% %% ���ݹ�һ��
% 
% % ѵ����
% [Pn_train,inputps] = mapminmax(P_train);
% [Tn_train,outputps] = mapminmax(T_train);
% 
% Tn_test = mapminmax(T_test);
% 
% pool=parpool;
%% GP����/ѵ��
sigma0 = std(T_train);

% gprMdl = fitrgp(Pn_train,Tn_train,'KernelFunction','ardsquaredexponential', 'OptimizeHyperparameters','auto','HyperparameterOptimizationOptions',...
%     struct('AcquisitionFunctionName','expected-improvement-plus'));
%  gprMdl = fitrgp(P_train,T_train,'KernelFunction','squaredexponential','BasisFunction','pureQuadratic','Optimizer','fmincon');

if D<=30
gprMdl = fitrgp(P_train,T_train,'KernelFunction','ardsquaredexponential', 'BasisFunction','pureQuadratic','Optimizer','fmincon','Sigma',sigma0,'Standardize',1);
else
 gprMdl = fitrgp(P_train,T_train,'KernelFunction','matern32','BasisFunction','pureQuadratic','Optimizer','fmincon','Sigma',sigma0,'Standardize',1);   
end

%%%%%%%%%%%%%%%%�ⲿ������dace�Ĵ���
% lob=repmat(1e-3,1,D);
% upb=repmat(1e3,1,D);
% theta=std(pastpos);
% [dmodel,perf]=dacefit(P_train,T_train,@regpoly0,@corrgauss,theta,lob,upb);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% GP�������

[t_sim,mse]=predict(gprMdl,T_test);
% [t_sim,mse]=predictor(T_test,dmodel);
% % ����һ��
% T_sim = mapminmax('reverse',tn_sim,outputps);
% else
%     T_test = p;
% %     Tn_test = mapminmax(T_test);
% %     [t_sim,mse]=predict(gprMdl,T_test);
%     [t_sim,mse]==predictor(T_test,dmodel);
% %     T_sim = mapminmax('reverse',t_sim,outputps);
% end
posfitG=t_sim;
% posfit=t_sim;
posmse=mse;
%  PopObj=[t_sim mse];
% estcount=estcount+ps;%���ƴ���
% fiteva=zeros(ps,1);
% fitest=ones(ps,1);
% maxmse=max(posmse);

end
